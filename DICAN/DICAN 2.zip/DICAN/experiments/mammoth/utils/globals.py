global GLOBALS

GLOBALS = {
    'SHOULD_STOP': False,
}
