"""
Modified version of https://github.com/openai/CLIP, which is licensed under the MIT License.
This version has been edited by https://github.com/JiazuoYu/MoE-Adapters4CL .
"""
