"""
This package contains utility functions for the ImageNet-R dataset.

It contains the list of images into train and test, as well as the list of classnames.
"""
