"""This module contains a collection of deprecated models."""
