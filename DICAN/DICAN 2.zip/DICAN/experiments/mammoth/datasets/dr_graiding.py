import sys
import os
import torch
import numpy as np
from torch.utils.data import DataLoader, Dataset
from datasets.utils.continual_dataset import ContinualDataset, store_masked_loaders  # 추가
from torchvision import transforms
import torch.nn.functional as F
from huggingface_hub import snapshot_download

# -----------------------------------------------------------------------------
# [중요] 윤영님의 DICAN 프로젝트 경로를 지정해주세요.
# -----------------------------------------------------------------------------
PROJECT_ROOT = '/root/DICAN'
if PROJECT_ROOT not in sys.path:
    sys.path.append(PROJECT_ROOT)

try:
    from data.base_loader import DDRBaseDataset
    from data.inc_loader import UnifiedIncrementalDataset
except ImportError as e:
    print(f"[Error] DICAN 모듈을 찾을 수 없습니다. PROJECT_ROOT를 확인해주세요: {PROJECT_ROOT}")
    raise e

class MammothWrapper(Dataset):
    """
    DICAN 데이터셋(Dict 반환)을 Mammoth 데이터셋(Tuple 반환)으로 변환하는 래퍼
    MammothDatasetWrapper의 요구 사항(data, targets 필드)을 충족해야 함
    """
    def __init__(self, dataset):
        self.dataset = dataset
        # MammothDatasetWrapper가 태스크 분할 및 마스킹을 위해 요구하는 필수 필드입니다.
        # DICAN 로더의 파일 경로(paths)와 라벨(labels) 리스트를 할당합니다.
        self.data = np.array(dataset.paths if hasattr(dataset, 'paths') else [])
        self.targets = np.array(dataset.labels if hasattr(dataset, 'labels') else [])

    def __len__(self):
        return len(self.dataset)

    def __getitem__(self, idx):
        data = self.dataset[idx]
        image = data['image']
        label = data['label']
        # Mammoth는 (이미지, 라벨, [추가 데이터]) 형태의 튜플 반환을 기대합니다.
        # 세 번째 인자인 'not_aug_inputs' 등은 Mammoth 래퍼가 내부적으로 처리하므로
        # 여기서는 기본적으로 필요한 (이미지, 라벨)만 반환합니다.
        return image, label

class DRGrading(ContinualDataset):
    NAME = 'dr_grading'
    SETTING = 'domain-il'
    N_CLASSES_PER_TASK = 5 
    N_TASKS = 4 
    SIZE = (3, 224, 224)

    def get_data_loaders(self):
        # 1. 딱 한 번만 필요한 데이터 싱크 (이미지 + 마스크)
        # 이 과정은 메인 프로세스에서 한 번만 실행되어 매우 안전합니다.
        print(f"[*] Syncing DDR data to local storage (Only grading & masks)...")
        local_path = snapshot_download(
            repo_id="ctmedtech/DDR-dataset",
            repo_type="dataset",
            allow_patterns=[
                f"DR_grading/{'train' if self.current_task==0 else 'valid'}.txt",
                "DR_grading/**/*.jpg",
                "lesion_segmentation/**/*"
            ],
            token=os.getenv("HF_TOKEN")
        )

        if self.current_task == 0:
            # 로컬 경로(local_path)를 넘겨줍니다.
            train_raw = DDRBaseDataset(root_dir=local_path, split='train', img_size=224)
            test_raw = DDRBaseDataset(root_dir=local_path, split='valid', img_size=224)
        else:
            session_id = self.current_task 
            session_name = {1: "APTOS", 2: "Messidor-2", 3: "DRAC22"}.get(session_id, "Unknown")
            print(f"  -> Incremental Session {session_id}: {session_name}")

            train_raw = UnifiedIncrementalDataset(
                session_id=session_id,
                data_dir='/root/DICAN_DATASETS',
                img_size=224,
                shot=10,
                split='train'
            )
            test_raw = UnifiedIncrementalDataset(
                session_id=session_id,
                data_dir='/root/DICAN_DATASETS',
                img_size=224,
                shot=None, 
                split='test'
            )

        # 2. MammothWrapper로 감싸기 (data, targets 필드 포함)
        train_dataset = MammothWrapper(train_raw)
        test_dataset = MammothWrapper(test_raw)

        # 3. [핵심] Mammoth 전용 래퍼 및 데이터 로더 생성
        # 이 함수가 내부적으로 MammothDatasetWrapper로 감싸고 self.train_loader 등을 업데이트합니다.
        train_loader, test_loader = store_masked_loaders(train_dataset, test_dataset, self)

        return train_loader, test_loader

    def get_transform(self):
        return transforms.Compose([transforms.ToTensor()])
    
    @staticmethod
    def get_loss():
        return F.cross_entropy

    @staticmethod
    def get_normalization_transform():
        return transforms.Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225))