"""
Utility functions for the TwF model.
"""
